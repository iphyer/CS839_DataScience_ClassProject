All the documents are in `Data` folder.

The Entity type that is marked up in these documents( 360 TXT files ) is Person Names and are marked up in the documents using 

```
<> Person Names </> 

```